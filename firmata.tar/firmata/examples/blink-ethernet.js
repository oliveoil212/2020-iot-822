/**
 * Sample script to blink LED 13
 */


var ledPin = 13;

var firmata = require("../lib/firmata");
var EtherPort = require("../../etherport/lib/wtf.js");

// var eport = new EtherPort(3030);

// console.log(eport);


// var board = new firmata.Board(new EtherPort(3030), function(err) {



//   if (err) {
//     console.log(err);
//     return;
//   }
//   console.log("connected");

//   console.log("Firmware: " + board.firmware.name + "-" + board.firmware.version.major + "." + board.firmware.version.minor);

//   var ledOn = true;
//   board.pinMode(ledPin, board.MODES.OUTPUT);

//   setInterval(function() {

//     if (ledOn) {
//       console.log("+");
//       board.digitalWrite(ledPin, board.HIGH);
//     } else {
//       console.log("-");
//       board.digitalWrite(ledPin, board.LOW);
//     }

//     ledOn = !ledOn;

//   }, 500);

// });
