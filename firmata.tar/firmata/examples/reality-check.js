var Board = require("../lib/firmata").Board;
var SerialPort = require("serialport");
var rport = /usb|acm|^com/i;

SerialPort.list(function(err, ports) {
  ports.forEach(function(port) {
    if (rport.test(port.comName)) {
      console.log("ATTEMPTING: ", port.comName);

      var board = new Board(port.comName);

      board.on("ready", function() {
        console.log("Ready");

        console.log(this.getSamplingInterval());

        // this.analogRead(0, function(adc) {
        //   console.log(adc);
        // });

        this.pinMode(14, this.MODES.INPUT);
        this.digitalRead(14, function(data) {
          console.log(data);
        });

        // this.analogRead(0, function(adc) {
        //   console.log(adc);
        // });
      });
    }
  });
});
